biblatex-caspervector: Casper Ti. Vector's biblatex style
---------------------------------------------------------

Maintainer: Casper Ti. Vector <CasperVector@gmail.com>
Homepage: <https://gitea.com/CasperVector/biblatex-caspervector>
Licence: LaTeX Project Public Licence 1.3 or later

This package provides a simple, nice and easily extensible
biblography/citation style for Chinese LaTeX users.

This file (`README.txt') is *NOT* intended as the documentation for
this package; please see the file `caspervector.pdf' instead.

